interface HTMLElement extends HTMLElement {
  srcObject: MediaStream
}

interface MediaDevices extends MediaDevices {
  getDisplayMedia: any
}
